// OemoAcceptor.h,v 1.5 1999/09/22 03:13:38 jcej Exp

#ifndef OEMO_ACCEPTOR_H
#define OEMO_ACCEPTOR_H

#pragma warning( disable: 4786 4800 4365 )

#include "ace/Acceptor.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */


#include "ace/SOCK_Acceptor.h"


#include "OemoThreadPool.h"
#include "thread_pool.h"
#include "OemoProtocolData.h"
#include "OemoImapHandler.h"


namespace OemoProtocolImpl
{
	

	//enumerations
	enum concurrency_t
	{
		single_threaded_,
		thread_per_connection_,
		thread_pool_
	};

	typedef ACE_Acceptor <OemoHandler, ACE_SOCK_ACCEPTOR> OemoAcceptor_Base;

	//class OemoAcceptor
	class OemoAcceptor : public OemoAcceptor_Base
	{
		public:

		  typedef OemoAcceptor_Base inherited;
  
		  OemoAcceptor (int concurrency = thread_pool_);

		  OemoAcceptor (OemoThreadPool &thread_pool);

		  ~OemoAcceptor (void);

		  int open (const ACE_INET_Addr &addr,
					ACE_Reactor *reactor,
					OemoProtocolDataPtr instance_data ,
					int pool_size = OemoThreadPool::default_pool_size_ );

		  int close (void);		 

		protected:

		  int concurrency_;

		  OemoThreadPool private_thread_pool_;

		  OemoThreadPool &the_thread_pool_;

		  OemoProtocolDataPtr m_instanceData;

		public:	

		  //accessors
		  int concurrency (void)
		  {
			return this->concurrency_;
		  }

		  OemoThreadPool *thread_pool (void)
		  {
			return &this->the_thread_pool_;
		  }

		  int thread_pool_is_private (void)
		  {
			return &the_thread_pool_ == &private_thread_pool_;
		  }

		  OemoProtocolDataPtr Data() 
		  {
			  return ( m_instanceData );
		  }

		  //mutators
		  void thread_pool( ACE_Thread_Manager* thrd_mgr )
		  {
			  ACE_Task<ACE_MT_SYNCH> ( thr_mgr );
		  }

		  inline void Data( OemoProtocolDataPtr data )
		  {
			  m_instanceData = data;
		  }

	};

}

namespace opi = OemoProtocolImpl;
#endif /* OEMO_ACCEPTOR_H */

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OemoImapStrings.rc
//
#define oemo_imap_fetch_fast            1
#define oemo_imap_fetch_all             2
#define oemo_imap_fetch_full            3
#define oemo_imap_fetch_flags           4
#define oemo_imap_fetch_internaldate    5
#define oemo_imap_fetch_rfc822size      6
#define oemo_imap_fetch_envelope        7
#define oemo_imap_fetch_body            8
#define oemo_imap_fetch_bodypeek        9
#define oemo_imap_fetch_header          10
#define oemo_imap_fetch_headerfields    11
#define oemo_imap_fetch_rfc822          12
#define oemo_imap_fetch_text            13
#define oemo_imap_fetch_size            14
#define oemo_imap_fetch_uid             15
#define oemo_imap_fetch_bodystructure   16
#define oemo_imap_fetch_rfc822text      20
#define oemo_imap_fetch_bodyfull        21
#define IDS_STRING22                    22
#define IDS_STRING23                    23
#define IDS_STRING24                    24
#define IDS_STRING25                    25
#define IDS_STRING26                    26
#define IDS_STRING27                    27
#define IDS_STRING28                    28
#define IDS_STRING29                    29
#define oemo_imap_utils_proc_timezone   30
#define oemo_imap_utils_fetchenvelope   31
#define oemo_imap_utils_fetchbodystructure 32

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
